<!DOCTYPE html>
<html lang="en">
<head>

     <title>e-Gizi Kalkulator Kalori</title>

     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/animate.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/magnific-popup.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/templatemo-style.css">

     <!-- DATA TABLE -->
<!--    <script src="js/datatables_jquery-3.1.0.js"></script>
    <script src="js/datatables_jquery.dataTables.min.js"></script>
    <script src="js/datatables_dataTables.bootstrap.min.js"></script>-->
    <link rel="stylesheet" href="css/dataTables.bootstrap.css">
<!--    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>-->
  

    
    
</head>