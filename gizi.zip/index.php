<?php
session_start();

$page = !empty($_GET['page']) ? $_GET['page'] : "1";
?>
<?php
 include('header.php');
 ?>
<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- MENU -->
     <section id='agahgshaghsgahsg' class="navbar custom-navbar navbar-fixed-top top-nav-collapse" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- LOGO TEXT HERE -->
                    <a  class="navbar-brand">e-Gizi<span>.</span> Kalkulator Kalori</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li <?php if($page==1) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                             <a href="index.php?page=1" class="smoothScroll">Beranda</a></li>
                         <li <?php if($page==2) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                             <?php if(isset($_SESSION['lv_user'])){?>
                             <a href="index.php?page=2">Kalkulator Kalori</a></li>
                             <?php }?>
                         <li><a href="<?php if($page!=1) { echo "index.php?page=1#about"; } else { echo "#about"; } ?>" class="smoothScroll">About</a></li>
                         <li><a href="<?php if($page!=1) { echo "index.php?page=1#contact"; } else { echo "#contact"; } ?>" class="smoothScroll">Contact</a></li>
                          <li <?php if($page==4) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                              <?php if(isset($_SESSION['lv_user'])){?>      
                              <a href="index.php?page=4">Akun</a></li>
                                <?php }?>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <?php
                                    if (isset($_SESSION['nmuser'])){
                                    echo $_SESSION['nmuser'].'<a href="sistem.php?op=out"><button type="button" class="section-btn"> Logout </button></a> ';
                                    } else {echo '
                                    <button type="button" class="section-btn" data-toggle="modal" data-target="#login">
                                    Login
                                    </button>';
                       }?>
                    </ul>
                   
               </div>

          </div>
     </section>
<?php	
switch($page)
{
case('1'): include_once('./page/home.php'); break;	
case('2'): include_once('./page/kalkulatorkalori.php'); break;
case('3'): include_once('./page/register.php'); break;	
case('4'): include_once('./page/akun.php'); break;
default:   include_once('./page/home.php'); break;
}			
?>


     <!-- FOOTER -->
<?php 
include('footer.php');
?>
<?php
  include_once('login.php');
?>

     <!-- SCRIPTS -->
     <script src="https://www.google.com/recaptcha/api.js"></script>
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/jquery.stellar.min.js"></script>
     <script src="js/wow.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/jquery.magnific-popup.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>
     
     <script src="js/jquery-1.11.1.min.js"></script>
     <script src="js/jquery.dataTables.min.js"></script>
     <script src="js/dataTables.bootstrap.js"></script>
<script type="text/javascript">
            $(function() {
                $('#riwayat-akun').dataTable();
            });
        </script>
</body>
</html>

