<!-- Modal -->
<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLongTitle">Login</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                                <form action="sistem.php?op=login" method="post">
                                    <div class="form-group">
                                        <label>Username</label>
                                        <input name="username"  type="text" class="form-control" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input name="password" type="password" class="form-control" placeholder="Password">
                                    </div>
                                    <div class="g-recaptcha" data-sitekey="6LfNAXsUAAAAAHZJJaTgurdX2VYqikgwOB8VOVvt"></div>
                                <button type="submit" name="login" value="Login" class="btn btn-info">Log in</button>
                                </form>
      </div>
      <div class="modal-footer">
        Gak Punya Akun ? <a href="index.php?page=3"> Daftar </a>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
