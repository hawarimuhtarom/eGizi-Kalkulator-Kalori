<?php
include "./db_gizi.php";
$sqlquery = "SELECT id_user FROM user WHERE username='".$_SESSION['username']."'";
$hasilquery = $connect->query($sqlquery);
$id_user = $hasilquery->fetch();
$user = $id_user['id_user'];
$_COOKIE['user'] = $user;

$sql = $connect->prepare("SELECT a.nama, a.jk, a.tinggi_badan, a.berat_badan, a.usia, a.level_aktivitas, a.hasil, b.menu FROM log_hitung as a, menu as b WHERE a.id_menu = b.id_menu AND a.id_user ='".$_COOKIE['user']."'ORDER BY id_log DESC");
$sql->execute();
?>

<!-- ABOUT -->
     <section id="akun" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="about-info">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.2s">
                                  <h2>Aktivitas Penghitungan Akun Anda</h2>
                              </div>
<table id="riwayat-akun" class="table table-striped table-bordered" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Sex</th>
            <th>TB</th>
            <th>BB</th>
            <th>Usia</th>
            <th>Lvl</th>
            <th>Kalori</th>
            <th>Menu</th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>Nama</th>
            <th>Sex</th>
            <th>TB</th>
            <th>BB</th>
            <th>Usia</th>
            <th>Lvl</th>
            <th>Kalori</th>
            <th>Menu</th>
        </tr>
    </tfoot>
    <tbody>
        <?php while($r=$sql->fetch()){ ?>
         <tr>
        <td><?php echo $r['nama']; ?></td>
        <td><?php echo $r['jk']; ?></td>
        <td><?php echo $r['tinggi_badan']; ?></td>
        <td><?php echo $r['berat_badan']; ?></td>
        <td><?php echo $r['usia']; ?></td>
        <td><?php echo $r['level_aktivitas']; ?></td>
        <td><?php echo $r['hasil']; ?></td>
        <td><?php echo $r['menu']; ?></td>
        </tr>

        <?php }?>
       
       </tbody>
</table>
                             

        
                              <div class="wow fadeInUp" data-wow-delay="0.4s">
                                  <h4>Keterangan Level Aktifitas</h4>
                                   <p>tidakaktif = Tidak Aktif ( minim aktifitas fisik, jarang / tak pernah olahraga</p>
                                   <p>ringan = Aktivitas fisik ringan ( 1-3 hari seminggu berolahraga ) </p>
                                   <p>sedang = Aktivitas fisik sedang ( 3-5 hari seminggu berolahraga )</p>
                                   <p>berat = Aktivitas fisik berat ( 6-7 hari seminggu berolahraga )</p>
                                   <p>sangatberat = Aktivitas fisik sangat berat ( 2x1 hari berolahraga / menuntut fisik ) </p>
                              </div>
                         </div>
                    </div>

<!--                    <div class="col-md-6 col-sm-12">
                         <div class="wow fadeInUp about-image" data-wow-delay="0.6s">
                              <img src="images/about-image.jpg" class="img-responsive" alt="">
                         </div>
                    </div>-->
                    
               </div>
          </div>
     </section>