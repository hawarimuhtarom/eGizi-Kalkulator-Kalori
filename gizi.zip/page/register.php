     
<!-- ABOUT -->
     <section id="register" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="about-info">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.2s">
                                   <h4>Isi data diri dan bergabung di e-Gizi Kalkulator Kalori</h4>
                                   <h2>Sign Up</h2>
<?php 
include_once 'db_gizi.php';

error_reporting(0);


if(!isset($_SESSION['username'] )== 0) { /* Halaman ini tidak dapat diakses jika belum ada yang login
	header('Location: home.php'); */
}

$username 		 = $_POST['username'];
$email 			 = $_POST['email'];
$nmuser 		= $_POST['nmuser'];
$password 		 = md5($_POST['password']);
$confirmPassword = md5($_POST['confirmPassword']);

if(isset($username, $email, $password, $confirmPassword)) { 
	if(strstr($email, "@")) {
		if($password == $confirmPassword) {
			try {
				$sql = "SELECT * FROM user WHERE username = :username OR email = :email";
				$stmt = $connect->prepare($sql);
				$stmt->bindParam(':username', $username);
				$stmt->bindParam(':email', $email);
				$stmt->execute();
			}
			catch(PDOException $e) {
				echo $e->getMessage();
			}

			$count = $stmt->rowCount();
			if($count == 0) {
				try {
					$sql = "INSERT INTO user SET username = :username, email = :email, nmuser = :nmuser, password = :password";
					$stmt = $connect->prepare($sql);
					$stmt->bindParam(':username', $username);
					$stmt->bindParam(':email', $email);
                                        $stmt->bindParam(':nmuser', $nmuser);
					$stmt->bindParam(':password', $password);
					$stmt->execute();
				}
				catch(PDOException $e) {
					echo $e->getMessage();
				}
				if($stmt) {
					echo 'Username dan Email sudah pernah digunakan  <hr/>';
				}
			}else{
				echo "Username dan Email sudah pernah digunakan  <hr/>";
			}
		}else{
			echo "Password tidak sama  <hr/>";
		}
	}else{
		echo "Email Tidak Valid  <hr/>";
	}
}

?>
                              </div>
                              <div class="wow fadeInUp" data-wow-delay="0.4s">
                                  <form action="" method="post">
                                    
                                    <div class="form-group">
                                        <label>Full Name</label>
                                        <input type="text" name="nmuser" class="form-control" placeholder="Nama User">
                                    </div>
                                    <div class="form-group">
                                        <label>Username</label>
                                        <input type="text" name="username" class="form-control" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email"class="form-control" placeholder="Email">
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" name="password" class="form-control" placeholder="Password">
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <input input type="password" name="confirmPassword" class="form-control" placeholder="Confirm Password">
                                    </div>
                                    
                                   <button type="submit" name="register" value="Register" class="btn btn-success">Sign Up</button>

                                </form>
                                </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>

