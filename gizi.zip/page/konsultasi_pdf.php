<?php
$connect = koneksidatabase();
forma(); 
mysqli_close($connect);

function forma()
{
ob_start();
require('../fpdf17/fpdf.php');  
class PDF extends FPDF
{
    
function Header()
{
$this->SetFont('Arial','B',20);
$this->Cell(40);
$this->Cell(200,8,'DATA CEK KEBUTUHAN KALORI',0,1,'C');   	
$this->SetFont('Arial','B',17);
$this->Cell(40);	
$this->Cell(200,6,'e-Gizi Kalkulator Kalori',0,1,'C');
$this->SetFont('Arial','',7);    
$this->Cell(40);	
$this->Cell(200,6,'',0,1,'C');
$this->SetFont('Arial','',7);    
$this->Cell(40);
$this->Line(10, 30, 285, 30);

}
function Footer()
{
$this->Line(10, 288, 200, 283);
$this->SetY(-15);
$this->SetFont('Arial','I',7);
$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}'.', print date '.date('d/m/Y').', e-Gizi Kalkulator Kalori'.date('Y'),0,0,'R');
}
}

$hasil = sql_select();
$i=1;
$pdf=new PDF(); // FORM A
$pdf=new PDF('L','mm','A4');
$pdf->SetCreator('fpdf');
$pdf->AliasNbPages();
$pdf->AddPage();
 $pdf->Image('../images/poltekes.png',70,7,-300);
 
$pdf->SetXY(12,70);
$pdf->SetX(10); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Nama.',0,0);
$pdf->SetX(50); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Sex',0,0);
$pdf->SetX(65); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Tinggi Badan',0,0);
$pdf->SetX(100); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Berat Badan ',0,0);
$pdf->SetX(130); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Usia ',0,0);
$pdf->SetX(145); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Level Aktivitas ',0,0);
$pdf->SetX(180); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Kalori ',0,0);
$pdf->SetX(200); $pdf->SetFont('Arial','B',11); $pdf->Cell(0,6,'Menu ',0,0);
$pdf->SetXY(12,70); 
$i=1; $baris1=75;
while($data = $hasil->fetch(PDO::FETCH_ASSOC))
{
$pdf->SetXY(10,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["nama"],1,1);
$pdf->SetXY(50,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["jk"],1,1);
$pdf->SetXY(65,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["tinggi_badan"],1,1);
$pdf->SetXY(100,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["berat_badan"],1,1);
$pdf->SetXY(130,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["usia"],1,1);
$pdf->SetXY(145,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["level_aktivitas"],1,1);
$pdf->SetXY(180,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["hasil"],1,1);
$pdf->SetXY(200,$baris1); $pdf->SetFont('Arial','',10); $pdf->Cell(0,10,$data["menu"],1,1);
$baris1 = $baris1 + 4;
$i++;
}  
$pdf->SetTitle('DATA CEK KEBUTUHAN KALORI',TRUE);
$pdf->SetSubject('E-Gizi Kalkulator Kalori');
$filepdf='exportdata.pdf';
$pdf->Output($filepdf,'i');
$pdf->Close();
}

function koneksidatabase()
{
    include('../db_gizi.php');
	return $connect;
}

function sql_select()
{
  global $connect;
  $sql =  $connect->query(" SELECT a.nama, a.jk, a.tinggi_badan, a.berat_badan, a.usia, a.level_aktivitas, a.hasil, b.menu FROM log_hitung as a, menu as b WHERE a.id_menu = b.id_menu ORDER BY id_log DESC LIMIT 1"); 
  return $sql;
}


?>