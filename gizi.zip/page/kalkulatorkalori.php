
     <!-- HOME -->
     <section id="home" class="slider" data-stellar-background-ratio="0.5">
          <div class="row">

                    <div class="owl-carousel owl-theme">
                         

                         <div class="item item-second">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-8 col-sm-12">
                                             <h1>Apakah anda sudah menjalani hidup yang sehat ?</h1>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-third">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-8 col-sm-12">
                                             <h1>Apakah anda sudah mengetahui kebutuhan gizi harian anda ?</h1>
                                             <a href="index.php?page=2" class="section-btn btn btn-default smoothScroll">Yuk Cek !!!</a>
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>

          </div>
     </section>     
<!-- ABOUT -->
     <section id="kalkulatorkalori" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="about-info">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.2s">
                                   <h4>Kalkulator Kebutuhan Kalori</h4>
                                   <h2>Isi Data dibawah ini untuk menghitung kebutuhan kalori.</h2>
                              </div>
<?php
$connect= koneksidatabase();

if(isset($_COOKIE['id_menu'])){
    log_hitung();
    var_dump('running');
}


$sqlquery = "SELECT id_user FROM user WHERE username='".$_SESSION['username']."'";
$hasilquery = $connect->query($sqlquery);
$id_user = $hasilquery->fetch();
$user = $id_user['id_user'];
$_COOKIE['user'] = $user;


  
  
if(isset($_POST['hitung'])){
        $nama = $_POST['nama'];
	$jk = $_POST['jk'];
	$tinggibadan = $_POST['tinggibadan'];
	$beratbadan = $_POST['beratbadan'];
        $usia = $_POST['usia'];
        $aktivitas = $_POST['aktivitas'];
        

	switch ($jk) {
		case 'l':
			$hasil =66.5+(13.8*$beratbadan)+(5*$tinggibadan)-(6.8*$usia) ;
                        switch ($aktivitas) {
                               case 'tidakaktif':
                                                $hasilakhir=$hasil*1.2;
                               break;
                               case 'ringan':
                                                $hasilakhir=$hasil*1.375;
                               break;
                               case 'sedang':
                                                $hasilakhir=$hasil*1.55;
                               break;
                               case 'berat':
                                                $hasilakhir=$hasil*1.725;
                               break;
                               case 'sangatberat':
                                                $hasilakhir=$hasil*1.9;
                               break;}
                               $_COOKIE["hasil"] = $hasilakhir;
		break;
		case 'p':
			$hasil =655.1+(9.6*$beratbadan)+(1.9*$tinggibadan)-(4.7*$usia);
                        switch ($aktivitas) {
                               case 'tidakaktif':
                                                $hasilakhir=$hasil*1.2;
                               break;
                               case 'ringan':
                                                $hasilakhir=$hasil*1.375;
                               break;
                               case 'sedang':
                                                $hasilakhir=$hasil*1.55;
                               break;
                               case 'berat':
                                                $hasilakhir=$hasil*1.725;
                               break;
                               case 'sangatberat':
                                                $hasilakhir=$hasil*1.9;
                        break;}
                        $_COOKIE["hasil"] = $hasilakhir;

		break;		
	}
        
}

?>
                              <div class="wow fadeInUp" data-wow-delay="0.4s">
                                  <form method="post">
                                       <div class="form-group">
                                           <label for="nama">Nama</label>
                                           <input class="form-control" type="text" name="nama" placeholder="Nama">
                                       </div>
                                        <div class="form-group">
                                           <label for="jk">Jenis Kelamin</label>
                                           <select class="form-control" name="jk">
                                               <option value="l">Laki - Laki</option>
                                               <option value="p">Perempuan</option>
                                           </select>
                                       </div>
                                        <div class="form-group">
                                           <label for="tinggibadan">Tinggi Badan </label>
                                           <input class="form-control" type="text" name="tinggibadan" placeholder="Cm">
                                       </div>
                                        <div class="form-group">
                                           <label for="beratbadan">Berat Badan </label>
                                           <input class="form-control" type="text" name="beratbadan" placeholder="Kg">
                                       </div>
                                         <div class="form-group">
                                           <label for="usia">Usia </label>
                                           <input class="form-control" type="text" name="usia" placeholder="Tahun">
                                       </div>
                                        <div class="form-group">
                                           <label for="aktivitas">Aktivitas Fisik</label>
                                           <select class="form-control" name="aktivitas">
                                               <option value="tidakaktif" >Tidak Aktif ( minim aktifitas fisik, jarang / tak pernah olahraga</option>
                                               <option value="ringan" >Aktivitas fisik ringan ( 1-3 hari seminggu berolahraga )</option>
                                               <option value="sedang" >Aktivitas fisik sedang ( 3-5 hari seminggu berolahraga )</option>
                                               <option value="berat">Aktivitas fisik berat ( 6-7 hari seminggu berolahraga )</option>
                                               <option value="sangatberat">Aktivitas fisik sangat berat ( 2x1 hari berolahraga / menuntut fisik )</option>
                                           </select>
                                       </div>
                                      <input type="submit" name="hitung" value="Hitung" class="tombol">
                                      
                                      </form>
                                </div>
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="wow fadeInUp about-image" data-wow-delay="0.6s">
                              <img src="images/about-image.jpg" class="img-responsive" alt="">
                              <p>Kebutuhan kalori harian adalah jumlah kalori yang dibutuhkan oleh tubuh Anda setiap hari, untuk menjalankan fungsi utama tubuh, dan untuk melakukan aktivitas sehari-hari.  </p> 

                                <?php if(isset($_POST['hitung'])){ ?>
                                <span align="center"><h4> Kebutuhan kalori "<?php echo $nama;?>" setiap harinya adalah : </h4></span>
                                <span align="center"><h1> <?php echo $hasilakhir ; ?> </h1></span>
                                <p>Ini adalah jumlah kalori TOTAL yang Anda butuhkan untuk menjalani aktivitas sehari-hari.</p>
                                <span align="center"><h5>  Menu anjuran untuk anda konsumsi : </h5></span>
                                <?php
                                
                                global $id_menu;
                                
                                if(($hasilakhir > 1000)&& ($hasilakhir < 2000)){
                                $_COOKIE['id_menu'] = 1;
                                $id_menu = $_COOKIE['id_menu'];
                                $sqlquery = "SELECT menu FROM menu WHERE id_menu='$id_menu'";
                                $menu = $connect->query($sqlquery);
                                $hasilmenu = $menu->fetch();
                                echo "<span align='center'><h4>".$hasilmenu['menu']."</h4></span>";
                                
                                }elseif (($hasilakhir > 2000)&& ($hasilakhir < 3000)) {
                                $_COOKIE['id_menu'] = 2;
                                $id_menu = $_COOKIE['id_menu'];
                                $sqlquery = "SELECT menu FROM menu WHERE id_menu='$id_menu'";
                                $menu= $connect->query($sqlquery);
                                $hasilmenu = $menu->fetch();
                                echo "<span align='center'><h4>".$hasilmenu['menu']."</h4></span>";        
                                    }

                                    ?>
                                <p> Kamu bisa berkonsultasi lebih lanjut dengan Dokter dengan membawa hasil cek kebutuhan kalori harian kamu !!! </p>
                              <a href="page/konsultasi_pdf.php"> <button class="btn btn-info"> Download PDF Hasil Cek</button></a>

                                 <?php  }else{ ?>
                                <span align="center"><h4> Kebutuhan kalori anda setiap harinya adalah :</h4></span>
                                <span align="center"><h1> <?php echo '0' ; ?> </h1></span>
                                <?php } ?>	
                         </div>
                    </div>
                </div>
          </div>
     </section>

<?php
date_default_timezone_set('Asia/Jakarta');
$date = new DateTime('now');
$_COOKIE["timestamp"] = $date->format('Y-m-d H:i:s'); 


if(isset($_COOKIE['id_menu'])){
    log_hitung();
    
}

function koneksidatabase()
{
    include('./db_gizi.php');
	return $connect;
}

function log_hitung()
{
  global $connect;
  global $_POST; 
  

  $id_user = $_COOKIE['user'];
  $id_menu = $_COOKIE['id_menu'];
  $hasilakhir = $_COOKIE["hasil"];
        $nama = $_POST['nama'];
	$jk = $_POST['jk'];
	$tinggibadan = $_POST['tinggibadan'];
	$beratbadan = $_POST['beratbadan'];
        $usia = $_POST['usia'];
        $aktivitas = $_POST['aktivitas'];
        $timestamp = $_COOKIE["timestamp"];
  
  $baru = "INSERT INTO `log_hitung` (`id_log`, `id_user`, `id_menu`, `hasil`, `nama`, `jk`, `tinggi_badan`, `berat_badan`, `usia`, `level_aktivitas` , `timestamp`) VALUES (NULL, '$id_user', '$id_menu', '$hasilakhir', '$nama', '$jk', '$tinggibadan', '$beratbadan', '$usia', '$aktivitas', '$timestamp');";
  $connect->exec($baru);
}
?>

        
        
