<?php
session_start();
if (!isset($_SESSION['nmuser'])){
    header("location:../sistem.php?op=out");
}

$page = !empty($_GET['page']) ? $_GET['page'] : "1";
?>
<?php 
include 'header.php';
include '../db_gizi.php';
?>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div class="profile-userpic">
                            <img src="../upload/image/<?php   
                                    
                                     
                                    if (isset($_SESSION['nmuser'])){
                                        $sqlquery = "SELECT * FROM `user`WHERE nmuser ='".$_SESSION['nmuser']."'";
                                     $hasilquery = $connect->query( $sqlquery);
                                     $baris = $hasilquery->fetch();
                                         echo $baris['foto'];
                                    } else {
                                        echo 'user.png';
                                    }?>" class="img-responsive" alt="">
			</div>
			<div class="profile-usertitle">
                            <div class="profile-usertitle-name"><?php echo $_SESSION['nmuser']; ?></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="divider"></div>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<ul class="nav menu">
			<li <?php if($page==1) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                            <a href="index.php?page=1"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			<li <?php if($page==2) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                            <a href="index.php?page=2"><em class="fa fa-user">&nbsp;</em> Users</a></li>
                        <li <?php if($page==3) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                            <a href="index.php?page=3"><em class="fa fa-clone">&nbsp;</em> Log Hasil</a></li>
                        <li <?php if($page==4) { echo 'class="active"'; } else { echo 'class=""'; } ?>>
                            <a href="index.php?page=4"><em class="fa fa-navicon">&nbsp;</em> Menu</a></li>
<!--			<li><a href="charts.html"><em class="fa fa-bar-chart">&nbsp;</em> Charts</a></li>
			<li><a href="elements.html"><em class="fa fa-toggle-off">&nbsp;</em> UI Elements</a></li>
			<li><a href="panels.html"><em class="fa fa-clone">&nbsp;</em> Alerts &amp; Panels</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-navicon">&nbsp;</em> Multilevel <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li><a class="" href="#">
						<span class="fa fa-arrow-right">&nbsp;</span> Sub Item 1
					</a></li>
					<li><a class="" href="#">
						<span class="fa fa-arrow-right">&nbsp;</span> Sub Item 2
					</a></li>
					<li><a class="" href="#">
						<span class="fa fa-arrow-right">&nbsp;</span> Sub Item 3
					</a></li>
				</ul>
			</li>-->
<li>
    <?php
                                    if (isset($_SESSION['nmuser'])){
                                    echo '<a href="../sistem.php?op=out"><em class="fa fa-power-off">&nbsp;</em> Logout</a> ';
                                    } else {echo '
                                    <button type="button" class="section-btn" data-toggle="modal" data-target="#login">
                                    Login
                                    </button>';
                       }?>
</li>
		</ul>
	</div><!--/.sidebar-->
		
<?php	
switch($page)
{
case('1'): include_once('./page/dasboard.php'); break;	
case('2'): include_once('./page/users.php'); break;
case('3'): include_once('./page/loghitung.php'); break;	
case('4'): include_once('./page/menu.php'); break;
default:   include_once('./page/dasboard.php'); break;
}			
?>

      
<?php
include 'footer.php';
?>
