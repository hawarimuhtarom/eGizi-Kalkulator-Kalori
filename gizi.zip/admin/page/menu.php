<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Menu</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Menu</h1>
			</div>
		</div><!--/.row-->
 <?php
$a = !empty($_GET['a']) ? $_GET['a'] : "reset";
$id_menu = !empty($_GET['id']) ? $_GET['id'] : " ";   
$connect = koneksidatabase();
$a = @$_GET["a"];
$sql = @$_POST["sql"];


switch ($sql) {
   
    case "update": sql_update(); break;
    case "delete": sql_delete(); break;	
    case "insert": sql_insert(); break;
}

switch ($a) {
    case "reset" :  curd_read();   break;
    case "tambah":  curd_create(); break;
    case "edit"  :  curd_update($id_menu); break;	
    case "hapus"  : curd_delete($id_menu); break;  	
    default : curd_read(); break;
}

function curd_read()
{
   $hasil = sql_select();
  $i=1;

    ?>		
                <div class="row">
                                <div class="col-md-12">
                                <div class="alert bg-teal" role="alert"><em class="fa fa-lg fa-plus">&nbsp;</em> Daftar Penentuan Menu Asupan, Ingin menambahkan data ?</a>   
                                    <a href="index.php?page=4&a=tambah"><span class='btn  btn-success btn-sm'>Tambah </span> </a></div>
                                <table id="menu" class="table table-striped table-bordered" width="100%" cellspacing="0">
        <thead>
        <tr>
            <th>NO</th>
            <th>Kode</th>
            <th>Menu Asupan</th>
            <th>Action</th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>No</th>
            <th>Kode</th>
            <th>Menu Asupan</th>
            <th>Action</th>
         </tr>
    </tfoot>
    <tbody>
       <?php
  while($r = $hasil->fetch(PDO::FETCH_ASSOC))
  {
  ?>
         <tr>
        <td><?php echo $i; ?></td>
        <td><?php echo $r['id_menu']; ?></td>
        <td><?php echo $r['menu']; ?></td>
        <td>
            <a href="index.php?page=4&a=edit&id=<?php echo $r['id_menu']?>"><button class='btn  btn-warning btn-sm'>Edit</button></a>
            <a href="index.php?page=4&a=hapus&id=<?php echo $r['id_menu']?>"><button class='btn  btn-danger btn-sm'>Delete</button></a>
        </td>
        </tr>

        <?php $i++; }?>
       
       </tbody>
</table>
                             </div>   
                            </div>
                           </div>
<?php } ?>

<?php 
function formeditor($row)
  {
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-12"> 
				<div class="panel panel-orange">
					<div class="panel-heading dark-overlay">Data Menu Asupan </div>
					<div class="panel-body">
                                    <form>
                                      <div class="form-group">
                                        <label for="exampleFormControlInput1">ID Menu</label>
                                       <input  type="text" class="form-control" id="exampleFormControlInput1" name="id_menu" value="<?php  echo trim($row["id_menu"]) ?>"> 
                                      </div>

                                      <div class="form-group">
                                        <label for="exampleFormControlTextarea1">Menu Asupan</label>
                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" name="menu"><?php  echo trim($row["menu"]) ?></textarea>
                                      </div>
                                    </form>
                                            <a href="index.php?page=4&a=reset"><span class='btn  btn-info btn-sm'>Batal</a>
                                            <input class="btn btn-success btn-sm"  type="submit" name="action" value="Simpan" >                                        </div>
				</div>
</div>
</div>
  </div>
    </div>
<?php  }?>	

<?php 
function curd_create() 
{
?>
<form action="index.php?page=4&a=reset" method="post">
<input type="hidden" name="sql" value="insert" >
<?php
$row = array(
  "id_menu" => "",
    "menu" => ""
   ) ;
formeditor($row)
?>
</form>
<?php } ?>   
    
    
<?php 
function curd_update($id_menu) 
{
global $connect;
$hasil2 = sql_select_byid($id_menu);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<br>
<form action="index.php?page=4&a=reset" method="post">
<input type="hidden" name="sql" value="update" >
<input type="hidden" name="id_menu" value="<?php  echo $id_menu; ?>" >
<?php
formeditor($row)
?>
</form>
<?php } ?>


<?php 
function curd_delete($id_menu) 
{
global $connect;
$hasil2 = sql_select_byid($id_menu);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-12">
				<div class="panel panel-red">
					<div class="panel-heading dark-overlay">Penghapusan Data</div>
					<div class="panel-body">

<form action="index.php?page=4&a=reset" method="post">
<input type="hidden" name="sql" value="delete" >
<input type="hidden" name="id_menu" value="<?php  echo $id_menu; ?>" >
<p> Anda yakin akan menghapus data ? <p>
<a href="index.php?page=4&a=reset"><span class='btn  btn-info btn-sm'>Batal</a>
<input class='btn  btn-warning btn-sm' type="submit" name="action" value="Delete" >
                            </div>
                            </div>
    </div>
   </form>
<?php } ?>


<?php 
function koneksidatabase()
{
    include('../db_gizi.php');
	return $connect;
}

function sql_select_byid($id_menu)
{
  global $connect;
  $hasil2 = $connect->query(" select * from menu where id_menu = ".$id_menu);
  return $hasil2;
}
function sql_select()
{

  global $connect;
  $sql = "SELECT * from menu";
  $hasil2 = $connect->query($sql);
  return $hasil2;
  
}

function sql_insert()
{
  global $connect;
  global $_POST; 
  
  $id_menu= $_POST["id_menu"];
  $menu = $_POST["menu"];
  $sql  = $connect->query("INSERT INTO menu(id_menu,menu) VALUES ('$id_menu','$menu')");			  
  
}

function sql_update()
{
 global $connect;
  global $_POST; 
  
  $id_menu = $_POST["id_menu"];
  $menu = $_POST["menu"];
  $sql  = $connect->query("UPDATE `menu` SET `id_menu` = '$id_menu', `menu` = '$menu' WHERE `id_menu` = ".$id_menu);			  

}

function sql_delete()
{
  global $connect;
  global $_POST; 
  $id_menu = $_POST["id_menu"];
  
  $sql  = $connect->query(" delete from `log_hitung` where id_menu = ".$id_menu);			  
 
}
?>