	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Users</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Users</h1>
			</div>
		</div><!--/.row-->
<?php
$a = !empty($_GET['a']) ? $_GET['a'] : "reset";
$id_user = !empty($_GET['id']) ? $_GET['id'] : " ";   
$connect = koneksidatabase();
$a = @$_GET["a"];
$sql = @$_POST["sql"];

$upload = @$_POST["upload"];
switch ($upload) {
case "1": upload_data(); break;
}


switch ($sql) {
    case "insert": sql_insert(); break;
    case "update": sql_update(); break;
    case "delete": sql_delete(); break;	
}

switch ($a) {
    case "reset" :  curd_read();   break;
    case "tambah":  curd_create(); break;	
    case "edit"  :  curd_update($id_user); break;	
    case "hapus"  :  curd_delete($id_user); break;  	
    default : curd_read(); break;
}


function curd_read()
{ 
  $hasil = sql_select();
  $i=1;

  ?>


 <div class="row">
                                <div class="col-md-12">
                                <div class="alert bg-info" role="alert"><em class="fa fa-lg fa-user">&nbsp;</em> Daftar User e-Gizi Kalkulator Kalori, Ingin menambahkan data ?</a>   
                                    <a href="index.php?page=2&a=tambah"><span class='btn  btn-success btn-sm'>Tambah </span> </a></div>
                                <table id="menu" class="table table-striped table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Ava</th>
                                                <th>Usename</th>
                                                <th>Nama User</th>
                                                <th>Password</th>
						<th>Level</th>
                                                <th <?php if($_SESSION['lv_user']=="user") { echo 'class="hidden"'; }?>>Publish</th>
                                                <th>Action</th>
                                                                                              
                                            </tr>
                                        </thead>
                                        <tbody>
 <?php
  while($baris = $hasil->fetch(PDO::FETCH_ASSOC))
  {
  ?>
                                            <tr>
  <td><?php echo $i; ?></td>
  <td><img src="../upload/image/<?php echo $baris['foto']; ?>" width="70px" height="70px"> </td>
  <td><?php echo $baris['username']; ?></td>
  <td><?php echo $baris['nmuser']; ?></td>
  <td><?php echo $baris['password']; ?></td>
    <td><?php echo $baris['lv_user']; ?></td>
	 <td <?php if($_SESSION['lv_user']=="user") { echo 'class="hidden"'; }?>><?php echo $baris['publish']; ?></td>
  <td>
                                                      <a  href="index.php?page=2&a=edit&id=<?php echo $baris['id_user']; ?>"><span class='btn  btn-warning btn-sm'>UPDATE</span></a>	
                                                    <a  <?php if($_SESSION['lv_user']=="user") { echo 'class="hidden"'; }?>   href="index.php?page=2&a=hapus&id=<?php echo $baris['id_user']; ?>"><span class='btn  btn-danger btn-sm'>DELETE</span></a>	
                                                </td>
                                            </tr>
 <?php
   $i++;  
  }
  ?>
                                        </tbody>
                                    </table>
 <?php
}
 ?>
                                </div>
                            </div>
                        </div>
                </div>
</div>

<?php 
function formeditor($row)
  {
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-12"> 
				<div class="panel panel-warning">
					<div class="panel-heading">Data Users
						<span class="pull-right clickable panel-toggle"><em class="fa fa-toggle-up"></em></span></div>
					<div class="panel-body">
                                        <form>
                                      <div class="form-group">
                                        <label for="username">Username</label>
                                       <input  name="username" type="text" class="form-control" id="username"  value="<?php  echo trim($row["username"]) ?>"> 
                                      </div>
                                      <div class="form-group">
                                        <label for="nmuser">Nama User</label>
                                       <input  name="nmuser" type="text" class="form-control" id="nmuser" value="<?php  echo trim($row["nmuser"]) ?>"> 
                                      </div>
                                      <div class="form-group">
                                        <label for="password">Password</label>
                                       <input  name="password" type="password" class="form-control" id="password"  value="<?php  echo trim($row["password"]) ?>"> 
                                      </div>
                                      <div class="form-group">
                                        <label for="lv_user">Level User</label>
                                       <input  name="lv_user" type="text" class="form-control" id="lv_user" value="<?php  echo trim($row["lv_user"]) ?>"> 
                                      </div>
                                     <div class="form-group">
                                        <label for="publish">Publish</label>
                                       <input  name="publish" type="text" class="form-control" id="publish"  value="<?php  echo trim($row["publish"]) ?>"> 
                                      </div>
                                      <div class="form-group">
                                        <label for="foto">Foto</label>
                                       <input  type="file" name="userfile" id="userfile" class="form-control"  value="<?php  echo trim($row["foto"]) ?>"> 
                                      </div>
                                        </form>

					<a href="index.php?page=2&a=reset"><span class='btn  btn-warning btn-sm'>Batal</a>
                                        <input class="btn btn-success btn-sm"  type="submit" name="action" value="Simpan" >
					</div>
				</div>
			</div>
    </div>
    </div>

<?php  }?>	
<?php 
function curd_create() 
{
?>

<form action="index.php?page=2&a=reset" method="post" enctype="multipart/form-data" >
<input type="hidden" name="sql" value="insert" >
<input type="hidden" name="upload" value="1">
<?php
$row = array(
  "username" => "",
    "nmuser" => "",
    "password" => "",
	 "lv_user" => "",
	 "publish" => "",
    "userfile" => "default.jpg",
   ) ;
formeditor($row)
?>


</form>
<?php } ?>

<?php 
function curd_update($id_user) 
{
global $connect;
$hasil2 = sql_select_byid($id_user);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>

<br>
<form action="index.php?page=2&a=reset" method="post"  enctype="multipart/form-data">
<input type="hidden" name="sql" value="update" >
<input type="hidden" name="id_user" value="<?php  echo $id_user; ?>" >

<input type="hidden" name="action" value="upload">
<input type="hidden" name="upload" value="1">
<?php
formeditor($row)
?>
</form>
<?php } ?>

<?php 
function curd_delete($id_user) 
{
global $connect;
$hasil2 = sql_select_byid($id_user);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-12">
				<div class="panel panel-red">
					<div class="panel-heading dark-overlay">Penghapusan Data</div>
					<div class="panel-body">

<form action="index.php?page=2&a=reset" method="post">
<input type="hidden" name="sql" value="delete" >
<input type="hidden" name="id_user" value="<?php  echo $id_user; ?>" >
<p> Anda yakin akan menghapus data ? <p>
<a href="index.php?page=2&a=reset"><span class='btn  btn-info btn-sm'>Batal</a>
<input class='btn  btn-warning btn-sm' type="submit" name="action" value="Delete" >
                            </div>
                            </div>
    </div>
   </form>
                                            

<?php } ?>


<?php 
function koneksidatabase()
{
    include('../db_gizi.php');
	return $connect;
}

function sql_select_byid($id_user)
{
  global $connect;
  $hasil2 = $connect->query(" select * from user where id_user = ".$id_user);
  return $hasil2;
}
function sql_select()
{
  global $connect;
  if($_SESSION['lv_user']=="admin"){
  $sql = "select * from user";
  } else{
  $sql = "select * from user where username='" .$_SESSION['username']."' ";;    
  }
  $hasil2 = $connect->query($sql);
  return $hasil2;
  
}

function sql_insert()
{
  global $connect;
  global $_POST; 
  
  $namafile = $_FILES["userfile"]["name"];
    $file_ext = strtolower(substr($namafile, strpos($namafile,' .')+1));
    $newname = strtotime(date('Y-m-d H:i:s'));
    $newfile = $newname.$file_ext;
    $filephoto = basename($newfile);
  
  $username = $_POST["username"];
  $nmuser = $_POST["nmuser"];
  $password = md5($_POST["password"]);
  $lv_user = $_POST["lv_user"];
  $publish = $_POST["publish"];
  $sql  = $connect->query("INSERT INTO user(username,nmuser,password,lv_user,publish,foto) VALUES ('$username','$nmuser','$password','$lv_user','$publish','$filephoto')");			  
  
}



function sql_update()
{
 global $connect;
  global $_POST; 
  
  $namafile = $_FILES["userfile"]["name"];
    $file_ext = strtolower(substr($namafile, strpos($namafile,' .')+1));
    $newname = strtotime(date('Y-m-d H:i:s'));
    $newfile = $newname.$file_ext;
    $filephoto = basename($newfile);
  
  $id_user = $_POST["id_user"];
  $username = $_POST["username"];
  $nmuser = $_POST["nmuser"];
  $password = md5($_POST["password"]);
  $lv_user = $_POST["lv_user"];
  $publish = $_POST["publish"];
  $sql  = $connect->query("UPDATE `user` SET `username` = '$username', `nmuser` = '$nmuser', `password` = '$password', `lv_user` = '$lv_user', `publish` = '$publish', `foto` = '$filephoto' WHERE `id_user` = ".$id_user);			  

}

function sql_delete()
{
  global $connect;
  global $_POST; 
  $sql  = $connect->query(" delete from `user` where id_user = ".$_POST["id_user"]);			  
 
}


function upload_data()
{
if(isset($_POST["action"]))
{
//ambil parameter-parameter file yang diupload:
//nama, nama temp, ukuran dan type
$file_name = $_FILES["userfile"]["name"];
$file_tmp_name = $_FILES["userfile"]["tmp_name"];
$file_size = $_FILES["userfile"]["size"];
$file_type = $_FILES["userfile"]["type"];

//definisikan variabel untuk menangani error saat upload
$err_upload=0;

//pada contoh berikut file akan diupload ke direktori image
$dir_upload = "../upload/image/";

//mengambil ekstensi sebuah file
$file_ext = strtolower(substr($file_name, strpos($file_name,' .')+1));

//new name
$newname = strtotime(date('Y-m-d H:i:s'));

//menggabungkan new name dengan ekstensi
$newfile = $newname.$file_ext;

//buat nama untuk file hasil upload
$file_upload = $dir_upload . basename($newfile);

//cek keberadaan file hasil upload di server
if(file_exists($file_upload))
{
echo "Maaf, file yang sama sudah ada pada server kami <br />";
$err_upload=1;
}

//buat batasan maksimum ukuran file yang boleh diupload (dalam byte)
$max_size_upload=1000000000;

//cek apakah ukuran file yang diupload melebihi batas
if($file_size > $max_size_upload)
{
echo "Maaf, ukuran file yang diupload melebih ".$max_size_upload." byte <br /> ";
$err_upload=1;
}

//cek hanya type JPG, GIF dan PNG saja yang diijinkan
if(($file_type!="image/jpeg") && ($file_type!="image/gif") && ($file_type!="image/png"))
{
echo "Maaf, hanya file JPG, GIF dan PNG saja yang diperbolehkan <br />";
$err_upload=1;
}

//tampilkan error jika terjadi kesalahan
if($err_upload)
{
echo "Ada Error, proses upload dibatalkan";
}
//proses upload file jika semua benar
else
{
if(move_uploaded_file($file_tmp_name,$file_upload))
{
echo '<div class="alert bg-success" role="alert"><em class="fa fa-lg fa-checklist">&nbsp;</em> Data Berhasil Di Update<a href="index.php?page=2" class="pull-right"><em class="fa fa-lg fa-close"></em></a></div>';
}
else
{ echo "Proses upload gagal";

}
}
}
}
?>