<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Log Hasil</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Log Hasil</h1>
			</div>
		</div><!--/.row-->
<?php
$a = !empty($_GET['a']) ? $_GET['a'] : "reset";
$id_log = !empty($_GET['id']) ? $_GET['id'] : " ";   
$connect = koneksidatabase();
$a = @$_GET["a"];
$sql = @$_POST["sql"];


switch ($sql) {
   
    case "update": sql_update(); break;
    case "delete": sql_delete(); break;	
}

switch ($a) {
    case "reset" :  curd_read();   break;	
    case "edit"  :  curd_update($id_log); break;	
    case "hapus"  : curd_delete($id_log); break;  	
    default : curd_read(); break;
}

function curd_read()
{
   $hasil = sql_select();
  $i=1;

    ?>			<div class="row">
                                <div class="col-md-12">
                                <div class="alert bg-info" role="alert"><em class="fa fa-lg fa-info-circle">&nbsp;</em> Log Hasil merupakan catatan penghitungan kalori dan penentuan menu asupan harian yang dibutuhkan setiap harinya.</a></div>
                                <table id="log-hitung" class="table table-striped table-bordered" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Sex</th>
            <th>Tinggi Badan</th>
            <th>Berat Badan</th>
            <th>Usia</th>
            <th>Lvl</th>
            <th>Kalori</th>
            <th>Menu</th>
            <th>Time</th>
            <th>Action</th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>Nama</th>
            <th>Sex</th>
            <th>Tinggi Badan</th>
            <th>Berat Badan</th>
            <th>Usia</th>
            <th>Lvl</th>
            <th>Kalori</th>
            <th>Menu</th>
            <th>Time</th>
            <th>Action</th>
        </tr>
    </tfoot>
    <tbody>
       <?php
  while($r = $hasil->fetch(PDO::FETCH_ASSOC))
  {
  ?>
         <tr>
        <td><?php echo $r['nama']; ?></td>
        <td><?php echo $r['jk']; ?></td>
        <td><?php echo $r['tinggi_badan']; ?></td>
        <td><?php echo $r['berat_badan']; ?></td>
        <td><?php echo $r['usia']; ?></td>
        <td><?php echo $r['level_aktivitas']; ?></td>
        <td><?php echo $r['hasil']; ?></td>
        <td><?php echo $r['menu']; ?></td>
        <td><?php echo $r['timestamp']; ?></td>
        <td>
            <a href="index.php?page=3&a=hapus&id=<?php echo $r['id_log']?>"><button class='btn  btn-warning btn-sm'>Delete</button></a>
        </td>
        </tr>

        <?php }?>
       
       </tbody>
</table>
                             </div>   
                            </div>
                           </div>
<?php } ?>

<?php 
function curd_delete($id_log) 
{
global $connect;
$hasil2 = sql_select_byid($id_log);
$row =  $hasil2->fetch(PDO::FETCH_ASSOC);
?>
<div class="container-fluid">
<div class="row">
<div class="col-md-12">
				<div class="panel panel-red">
					<div class="panel-heading dark-overlay">Penghapusan Data</div>
					<div class="panel-body">

<form action="index.php?page=3&a=reset" method="post">
<input type="hidden" name="sql" value="delete" >
<input type="hidden" name="id_log" value="<?php  echo $id_log; ?>" >
<p> Anda yakin akan menghapus data ? <p>
<a href="index.php?page=3&a=reset"><span class='btn  btn-info btn-sm'>Batal</a>
<input class='btn  btn-warning btn-sm' type="submit" name="action" value="Delete" >
                            </div>
                            </div>
    </div>
   </form>
<?php } ?>


<?php 
function koneksidatabase()
{
    include('../db_gizi.php');
	return $connect;
}

function sql_select_byid($id_log)
{
  global $connect;
  $hasil2 = $connect->query(" select * from log_hitung where id_log = ".$id_log);
  return $hasil2;
}
function sql_select()
{

  global $connect;
  $sql = "SELECT a.id_log, a.nama, a.jk, a.tinggi_badan, a.berat_badan, a.usia, a.level_aktivitas, a.hasil, a.timestamp, b.menu FROM log_hitung as a, menu as b WHERE a.id_menu = b.id_menu ORDER BY id_log DESC";
  $hasil2 = $connect->query($sql);
  return $hasil2;
  
}


function sql_update()
{
 global $connect;
  global $_POST; 
  
  $nm_kabupaten = $_POST["nm_kabupaten"];
  $nm_provinsi = $_POST["nm_provinsi"];
  $maps = $_POST["maps"];
  $sql  = $connect->query("UPDATE `kabupaten` SET `nm_kabupaten` = '$nm_kabupaten', `nm_provinsi` = '$nm_provinsi', `maps` = '$maps' WHERE `id_kabupaten` = ".$id_kabupaten);			  

}

function sql_delete()
{
  global $connect;
  global $_POST; 
  $id_log = $_POST["id_log"];
  
  $sql  = $connect->query(" delete from `log_hitung` where id_log = ".$id_log);			  
 
}
?>