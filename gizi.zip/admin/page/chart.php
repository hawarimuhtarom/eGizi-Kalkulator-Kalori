<?php
include '../db_gizi.php';
$queryLK =('SELECT COUNT(*) as JumLK FROM log_hitung WHERE jk = "L" GROUP BY MONTH(timestamp)');
$LK = $connect->query($queryLK);
$queryPR =('SELECT COUNT(*) as JumPR FROM log_hitung WHERE jk = "P" GROUP BY MONTH(timestamp)');
$PR = $connect->query($queryPR);
$querymonth = ('SELECT DATE_FORMAT(timestamp, "%M") as Bulan FROM log_hitung GROUP BY MONTH(timestamp)');
$MONTH = $connect->query($querymonth);
?>

<script>
var randomScalingFactor = function(){ return Math.round(Math.random()*1000)};


	var lineChart = {
		labels : [
                    <?php 
                    while($row = $MONTH->fetch()){ 
                    ?> <?php echo "'".$row['Bulan']."',";?><?php     
                    }
                    ?>
                ],
		datasets : [
			{
				label: "Sex L",
				fillColor : "rgba(220,220,220,0.2)",
				strokeColor : "rgba(220,220,220,1)",
				pointColor : "rgba(220,220,220,1)",
				pointStrokeColor : "#fff",
				pointHighlightFill : "#fff",
				pointHighlightStroke : "rgba(220,220,220,1)",
				data : [
                                        <?php 
                                        while($row = $LK->fetch()){ 
                                        ?> <?php echo "'".$row['JumLK']."',";?><?php     
                                        }
                                        ?>
                                    ]
			},
			{
				label: "Sex P",
				fillColor : "rgba(48, 164, 255, 0.2)",
				strokeColor : "rgba(48, 164, 255, 1)",
				pointColor : "rgba(48, 164, 255, 1)",
				pointStrokeColor : "#fff",
				pointHighlightFill : "#fff",
				pointHighlightStroke : "rgba(48, 164, 255, 1)",
				data : [
                                    <?php 
                                        while($row = $PR->fetch()){ 
                                        ?> <?php echo "'".$row['JumPR']."',";?><?php     
                                        }
                                        ?>
                                ]
			}
		]

	}
</script>